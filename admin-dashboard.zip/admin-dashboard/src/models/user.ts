export interface User {
  userId: string;
  email: string;
  role: string;
}
